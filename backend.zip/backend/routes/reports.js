const express = require('express');
const Report = require('../models/Report');
const jwt = require('jsonwebtoken');

const router = express.Router();

// Middleware to protect routes
const auth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: "No token provided" });
  
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (e) {
    res.status(401).json({ error: "Token is not valid" });
  }
};

// Create a new report
router.post('/', auth, async (req, res) => {
  try {
    const { title, description, location, severity, imageUrl } = req.body;
    
    const newReport = new Report({
      title,
      description,
      location,
      severity,
      imageUrl,
      userId: req.user.id
    });
    
    const report = await newReport.save();
    res.json(report);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server Error" });
  }
});

// Get all reports
router.get('/', async (req, res) => {
  try {
    const reports = await Report.find().sort({ createdAt: -1 }).populate('userId', 'firstName lastName');
    res.json(reports);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server Error" });
  }
});

// Get reports by User ID
router.get('/my-reports', auth, async (req, res) => {
  try {
    const reports = await Report.find({ userId: req.user.id }).sort({ createdAt: -1 });
    res.json(reports);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server Error" });
  }
});

// Update Report Status (usually for admin, but leaving unprotected for demo purpose)
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const report = await Report.findByIdAndUpdate(
      req.params.id,
      { $set: { status } },
      { new: true }
    );
    res.json(report);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server Error" });
  }
});

module.exports = router;
